import UIKit
import Foundation
let a=609
if(a>=600){
    print("YES")
}
else{
    print("NO")
}
var x1=1,x2=2,y1=2,y2=1
var a1=pow(Double(x1-x2),2)
var b1=pow(Double(y1-y2),2)
var dist=sqrt(a1+b1)
print(abs(dist))
let bs=1540.0
var gs=bs+(500.0)+(0.98*bs)
print(gs)
