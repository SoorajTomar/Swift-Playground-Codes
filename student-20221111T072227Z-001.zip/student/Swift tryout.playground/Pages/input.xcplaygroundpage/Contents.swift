//: [Previous](@previous)

import Foundation
import UIKit
print("Enter Number 1:")
var n1=32
print("Enter Number 2:")
var n2=45
if (n1>n2){
    print(n1-n2)
}
else{
    print(n1+n2)}
var credit=21
switch credit{
case 36...Int.max:
    print("Hard")
case Int.min...11:
    print("Easy")
default:
    print("Medium")
}
