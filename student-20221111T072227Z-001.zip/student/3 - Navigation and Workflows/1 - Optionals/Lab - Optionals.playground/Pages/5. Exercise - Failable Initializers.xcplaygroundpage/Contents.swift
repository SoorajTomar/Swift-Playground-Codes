/*:
## Exercise - Failable Initializers

 Create a `Computer` struct with two properties, `ram` and `yearManufactured`, where both parameters are of type `Int`. Create a failable initializer that will only create an instance of `Computer` if `ram` is greater than 0, and if `yearManufactured` is greater than 1970, and less than 2020.
 */
struct Computer{
    var ram:Int?
    var yearManufactured:Int?
    init(_ a:Int,_ b:Int){
        if a>0 && b>1970 && b<2020{
            self.ram=a
            self.yearManufactured=b
        }
    }
}

//:  Create two instances of `Computer?` using the failable initializer. One instance should use values that will have a value within the optional, and the other should result in `nil`. Use if-let syntax to unwrap each of the `Computer?` objects and print the `ram` and `yearManufactured` if the optional contains a value.
var i1=Computer(2,1999)
var i2=Computer(-3,1995)
if let a=i1.ram,let b=i1.yearManufactured{
    print(a,b)
}
if let a=i2.ram, let b=i2.yearManufactured{
    print(a,b)
}
else{
    print(i2.ram,i2.yearManufactured)
}
/*:
[Previous](@previous)  |  page 5 of 6  |  [Next: App Exercise - Workout or Nil](@next)
 */
